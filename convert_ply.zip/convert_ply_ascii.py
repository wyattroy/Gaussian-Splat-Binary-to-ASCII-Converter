import plyfile
import sys
import os
import threading
import itertools
import time

# Spinner function
def spinning_cursor():
    for cursor in itertools.cycle('|/-\\'):
        if spinner_done:
            break
        print(f'\rProcessing... {cursor}', end='', flush=True)
        time.sleep(0.1)
    print('\rDone!          ', flush=True)

# Check if a filename was passed
if len(sys.argv) < 2:
    print("Usage: python convert_ply_ascii.py input_file.ply")
    sys.exit(1)

input_path = sys.argv[1]

# Make output path by adding _ascii
base, ext = os.path.splitext(input_path)
output_path = base + '_ascii.ply'

# Extract just the filename (no path)
filename_only = os.path.basename(base)

print(f"Converting {filename_only} ply!\n")
print("Big splats can take 5+ minutes to convert -- Stand by, my friend...\n")

# Start spinner in a separate thread
spinner_done = False
spinner_thread = threading.Thread(target=spinning_cursor)
spinner_thread.start()

# Load binary PLY
plydata = plyfile.PlyData.read(input_path)

# Force ASCII output
plydata.text = True

# Save new ASCII PLY
plydata.write(output_path)

# Stop spinner
spinner_done = True
spinner_thread.join()

print(f"\nSuccessfully converted {filename_only}.ply to {filename_only}_ascii.ply\n")
